import os
import shutil
import sqlite3
import tkinter as tk
from tkinter import filedialog

# Create a database connection and table
conn = sqlite3.connect('photos.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS photos
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              filename TEXT)''')
conn.commit()

# Define a function to move the photos and insert their filenames in the database
def move_photos():
    downloads_folder = filedialog.askdirectory(title='Valige kaust fotodega.')
    if downloads_folder:
        photo_folder = os.path.join(downloads_folder, 'fotod')
        if not os.path.exists(photo_folder):
            os.mkdir(photo_folder)
        for filename in os.listdir(downloads_folder):
            if filename.lower().endswith(('.jpg', '.png')):
                src_path = os.path.join(downloads_folder, filename)
                dst_path = os.path.join(photo_folder, filename)
                shutil.move(src_path, dst_path)
                c.execute('INSERT INTO photos (filename) VALUES (?)', (filename,))
        conn.commit()
        result_label.config(text='Fotode ümberpaigaldumine õnnestus.')

# Create the GUI
root = tk.Tk()
root.title('Paigalda fotosid')
root.geometry('400x120')

title_label = tk.Label(root, text='Vajutage nuppu, et viia fotod üle "fotode" kausta teie valitud kaustast.')
title_label.pack(pady=10)

move_button = tk.Button(root, text='Paigalda fotosid', command=move_photos)
move_button.pack(pady=10)

result_label = tk.Label(root, text='')
result_label.pack()

root.mainloop()